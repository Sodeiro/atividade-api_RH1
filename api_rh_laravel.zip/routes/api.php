<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DepartamentoController;
use App\Http\Controllers\FuncionarioController;

Route::apiResource('departamentos', DepartamentoController::class);
Route::get('departamentos/{id}/funcionarios', [DepartamentoController::class, 'funcionarios']);

Route::apiResource('funcionarios', FuncionarioController::class);
Route::get('funcionarios/{id}/departamento', [FuncionarioController::class, 'departamento']);
Route::get('funcionarios_com_departamentos', [FuncionarioController::class, 'comDepartamentos']);
