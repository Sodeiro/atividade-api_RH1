<?php

namespace App\Http\Controllers;
use App\Models\Departamento;
use Illuminate\Http\Request;

class DepartamentoController extends Controller {
    public function index() {
        return Departamento::all();
    }

    public function store(Request $request) {
        return Departamento::create($request->all());
    }

    public function show($id) {
        return Departamento::findOrFail($id);
    }

    public function update(Request $request, $id) {
        $departamento = Departamento::findOrFail($id);
        $departamento->update($request->all());
        return $departamento;
    }

    public function destroy($id) {
        Departamento::destroy($id);
        return response()->noContent();
    }

    public function funcionarios($id) {
        $departamento = Departamento::findOrFail($id);
        return $departamento->funcionarios;
    }
}
